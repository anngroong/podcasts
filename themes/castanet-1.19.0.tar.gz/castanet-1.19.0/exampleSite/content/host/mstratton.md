+++
Title = "Matt Stratton"
date = "2016-12-08T20:55:58-06:00"
Twitter = "mattstratton"
Website = "http://www.google.com/"
Type = "host"
Facebook = ""
Linkedin = "https://www.linkedin.com/in/mattstratton"
Pronouns = "He/Him"
GitHub = "mattstratton"
Thumbnail = "img/host/matt.png"
Pinterest = "mattstratton"
Instagram = "mattstratton"
YouTube = ""
Twitch = "mattstratton"
Hide = ""
+++
Matt Stratton is a solutions architect at Chef, where he demonstrates how Chef’s automation platform provides speed and flexibility to clients’ infrastructure. He is devoted to concepts like Continuous Delivery and Infrastructure as Code, and his license plate actually says “DevOps”. He lives in Chicago and has an unhealthy obsession with Doctor Who, Firefly, and Game of Thrones. And whiskey.
