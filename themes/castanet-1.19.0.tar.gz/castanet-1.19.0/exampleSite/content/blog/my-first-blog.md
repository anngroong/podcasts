+++
Description = "This is a blog post!"
Date = 2020-11-01T13:27:00-06:00
PublishDate = 2020-11-01T13:27:00-06:00 # this is the datetime for the when the epsiode was published. This will default to Date if it is not set. Example is "2016-04-25T04:09:45-05:00"
title = "My First Blog"
images = ["img/episode/default-social.jpg"]
Author = "mstratton"
blog_banner = "img/episode/default-banner.jpg"
blog_image = "img/episode/default.jpg"
categories = ["DevOps", "Deployment"]
tags = ["Version Control", "Git"]
series = ["The Nirvana of DevOps"]
#aliases = ["/##"]
+++
YOLO keytar scenester, williamsburg etsy mlkshk neutra hexagon photo booth church-key messenger bag. Lyft small batch enamel pin, bicycle rights la croix migas chartreuse ramps microdosing authentic pickled gochujang kombucha. Wolf vaporware stumptown, glossier vinyl everyday carry organic. Subway tile af tumblr listicle photo booth meh trust fund tote bag. Post-ironic gentrify direct trade blue bottle, fingerstache master cleanse butcher. Succulents ethical leggings hexagon vexillologist migas you probably haven't heard of them keytar sustainable church-key viral salvia hell of kinfolk. Lumbersexual taiyaki la croix literally man bun, truffaut mustache godard edison bulb artisan keytar jianbing air plant swag polaroid.

Actually vinyl fingerstache kickstarter +1 roof party, XOXO swag tousled cold-pressed authentic affogato selvage taiyaki schlitz. Stumptown tumeric lumbersexual, pok pok pabst butcher helvetica coloring book keytar williamsburg. Fam cloud bread meditation, post-ironic waistcoat narwhal chicharrones live-edge authentic try-hard cornhole bespoke kickstarter echo park portland. Cold-pressed lo-fi cornhole kinfolk. Sustainable scenester seitan, vape fanny pack put a bird on it succulents. 90's dreamcatcher messenger bag flannel +1 taxidermy occupy single-origin coffee four dollar toast master cleanse VHS. Small batch williamsburg tumeric meggings fanny pack pok pok paleo cardigan.

Leggings photo booth beard tumeric heirloom 90's flexitarian locavore unicorn, salvia humblebrag biodiesel lomo. Bushwick chillwave distillery kombucha tbh cray roof party tacos. Wayfarers fingerstache irony, celiac schlitz microdosing austin keytar echo park. Flannel drinking vinegar austin sustainable banjo bicycle rights keytar subway tile intelligentsia williamsburg humblebrag vinyl. Prism keffiyeh mlkshk, venmo glossier distillery +1 raw denim edison bulb pinterest crucifix. Freegan iceland chartreuse leggings hella single-origin coffee tilde. Swag neutra chia before they sold out.

Cred tilde flannel shaman helvetica cronut bitters mlkshk. Selvage lyft chartreuse shaman man braid gastropub tattooed post-ironic organic freegan austin forage. Enamel pin unicorn +1 schlitz lomo man bun wayfarers. Readymade bespoke polaroid iceland sriracha schlitz tousled flannel. Raw denim enamel pin fanny pack sustainable, butcher deep v thundercats try-hard forage woke fam keffiyeh. Cronut kitsch cray shoreditch pabst paleo normcore DIY bespoke cardigan pug. Crucifix bitters knausgaard neutra, viral distillery selvage banh mi activated charcoal cray.

Tofu taiyaki sriracha unicorn try-hard cornhole cloud bread keytar wayfarers kinfolk pour-over art party small batch. Tousled DIY coloring book wolf, small batch master cleanse austin letterpress af. Humblebrag pop-up vaporware, readymade organic woke af la croix succulents. Yr hoodie mlkshk woke whatever portland cornhole, brunch raw denim shaman YOLO prism bicycle rights. Helvetica la croix fingerstache chambray tumblr ramps blog waistcoat 8-bit. Dreamcatcher stumptown distillery mixtape sriracha blog la croix. Pabst copper mug street art, kinfolk letterpress chambray swag occupy shoreditch echo park migas post-ironic.

Dummy text? More like dummy thicc text, amirite?
