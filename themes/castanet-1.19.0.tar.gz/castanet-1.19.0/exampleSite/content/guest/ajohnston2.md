+++
Title = "Alan Johnston"
date = "2020-02-10T09:12:39-05:00"
Twitter = "https://twitter.com/deserunt"
Website = "http://Agimba.info"
Type = "guest"
Facebook = "adipisci"
Linkedin = "https://www.linkedin.com/in/ut"
Pronouns = ""
GitHub = "tempora"
Thumbnail = "img/guest/ajohnston.jpg"
Pinterest = ""
Instagram = ""
YouTube = ""
guest_group = "ajohnston"
+++
this is the newer version of Alan
