+++
date = "2016-09-25T02:11:48-05:00"
description = "guests of the show"
title = "Guests of HugoCast"
aliases = "/guests"
+++

Want to be a guest on the HugoCast? Send us an email!
